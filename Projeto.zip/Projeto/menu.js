document.addEventListener('DOMContentLoaded', () => {
  // Seleciona os botões estritamente pela ordem dentro da div .buttons
  const btnPlay = document.querySelector('.buttons .btn:nth-child(1)');
  const btnOptions = document.querySelector('.buttons .btn:nth-child(2)');
  const btnExit = document.querySelector('.btn-exit');
  
  const optionsModal = document.getElementById('options-modal');
  const btnCloseOptions = document.getElementById('close-options');

  // Ação do botão jogar controlada aqui pelo JS
  if (btnPlay) {
    btnPlay.addEventListener('click', () => {
      window.location.href = 'game.html';
    });
  }

  // Ação de abrir opções
  if (btnOptions) {
    btnOptions.addEventListener('click', () => {
      optionsModal.style.display = 'flex';
    });
  }

  // Ação de fechar opções
  if (btnCloseOptions) {
    btnCloseOptions.addEventListener('click', () => {
      optionsModal.style.display = 'none';
    });
  }

  // Fechar clicando fora do modal
  window.addEventListener('click', (e) => {
    if (e.target === optionsModal) {
      optionsModal.style.display = 'none';
    }
  });

  // Ação do botão sair
  if (btnExit) {
    btnExit.addEventListener('click', () => {
      if (confirm('Tem certeza que deseja sair do Contagem Edition?')) {
        document.body.innerHTML = `
          <div style="background: rgba(140, 20, 20, 0.85); color: white; height: 100vh; width: 100vw; display: flex; flex-direction: column; align-items: center; justify-content: center; font-family: 'Press Start 2P', monospace; gap: 30px; z-index: 999999; position: fixed; inset: 0;">
            <h1 style="font-size: 2.5rem; text-shadow: 4px 4px 0 #000; text-align:center;">Você saiu do jogo!</h1>
            <p style="font-size: 1rem;">Obrigado por jogar.</p>
            <button class="btn" onclick="window.location.reload()" style="font-family: 'Press Start 2P', monospace; padding: 10px 20px; cursor: pointer;">Voltar ao Menu</button>
          </div>
        `;
      }
    });
  }
});