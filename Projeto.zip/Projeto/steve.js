const canvas     = document.getElementById('steve');
const ctx        = canvas.getContext('2d');
const canvasBack = document.getElementById('steve-back');
const ctxB       = canvasBack.getContext('2d');

ctx.imageSmoothingEnabled  = false;
ctxB.imageSmoothingEnabled = false;

const S = 14; // tamanho de cada pixel

// ── PALETA ───────────────────────────────────────────────
const C = {
  _:  null,
  sk: '#D4A97A',  // pele bege
  sh: '#B8895A',  // pele sombra
  hk: '#2E1503',  // cabelo marrom escuro
  hl: '#3D1F08',  // cabelo lateral (detalhe)
  ey: '#1A1A1A',  // olho preto
  es: '#7A4A20',  // sombra abaixo do olho
  ns: '#C08858',  // nariz (sombra sutil)
  mb: '#A0604A',  // boca marrom rosado
  ml: '#C07860',  // boca claro (sorriso)
  rk: '#6B1212',  // vermelho vinho
  rd: '#4A0A0A',  // vermelho escuro
  wh: '#DCDCDC',  // branco ombro
  fy: '#FFE000',  // chama amarela
  fo: '#FF6A00',  // chama laranja
  pw: '#E8E8E8',  // branco short
  pr: '#6B1212',  // pixel vermelho short
  pk: '#1A1A1A',  // pixel preto perna
  lg: '#3A3A3A',  // canela
  sv: '#6B1212',  // tênis vermelho
  sb: '#C0C0C0',  // sola cinza
};

// ── CABEÇA FRENTE 8×8 ────────────────────────────────────
// linha 0-1: cabelo topo (reto e quadrado)
// linha 2:   transição cabelo/pele
// linha 3-7: rosto
const HEAD_F = [
//  0     1     2     3     4     5     6     7
  [C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk],  // cabelo topo
  [C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk],  // cabelo topo
  [C.hk, C.hl, C.sk, C.sk, C.sk, C.sk, C.hl, C.hk],  // franja
  [C.sk, C.sk, C.sk, C.sk, C.sk, C.sk, C.sk, C.sk],  // testa
  [C.sk, C.sk, C.ey, C.sk, C.sk, C.ey, C.sk, C.sk],  // olhos centralizados
  [C.sk, C.sk, C.es, C.ns, C.ns, C.es, C.sk, C.sk],  // sombra olho + nariz
  [C.sk, C.sk, C.sk, C.mb, C.mb, C.sk, C.sk, C.sk],  // boca centralizada
  [C.sh, C.sh, C.sh, C.sh, C.sh, C.sh, C.sh, C.sh],  // queixo
];

// ── CABEÇA COSTAS 8×8 ────────────────────────────────────
const HEAD_B = [
  [C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk],
  [C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk],
  [C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk],
  [C.hk, C.hl, C.hk, C.hk, C.hk, C.hk, C.hl, C.hk],
  [C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk],
  [C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk],
  [C.hk, C.hl, C.hk, C.hk, C.hk, C.hk, C.hl, C.hk],
  [C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk, C.hk],
];

// ── TRONCO FRENTE 8×12 ───────────────────────────────────
// linha 0:   ombros com detalhe branco
// linhas 1-11: casaco vinho com chama no centro
const TORSO_F = [
  [C.wh, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.wh],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.fy, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.fy, C.fy, C.fo, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.fo, C.fo, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.fo, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rd, C.rd, C.rd, C.rd, C.rd, C.rd, C.rd, C.rd],
];

// ── TRONCO COSTAS 8×12 ───────────────────────────────────
const TORSO_B = [
  [C.wh, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.wh],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk, C.rk],
  [C.rd, C.rd, C.rd, C.rd, C.rd, C.rd, C.rd, C.rd],
];

// ── BRAÇO FRENTE 4×12 ────────────────────────────────────
// linha 0: faixa branca ombro
// linhas 1-10: manga vermelha
// linha 11: pulso pele
const ARM_F = [
  [C.wh, C.wh, C.wh, C.wh],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.rk, C.rk, C.rk, C.rk],
  [C.sk, C.sk, C.sk, C.sk],
];

// braço costas igual à frente
const ARM_B = ARM_F;

// ── PERNA ESQUERDA 4×12 ──────────────────────────────────
// linhas 0-4:  short branco com pixels vermelhos
// linha 5:     detalhe vermelho escuro (joelho)
// linha 6:     pixel preto centro
// linhas 7-9:  canela cinza
// linha 10:    tênis vermelho
// linha 11:    sola cinza claro
const LEG_L = [
  [C.pw, C.pw, C.pw, C.pw],
  [C.pr, C.pw, C.pw, C.pw],  // pixel vermelho
  [C.pw, C.pw, C.pr, C.pw],  // pixel vermelho
  [C.pw, C.pw, C.pw, C.pw],
  [C.pw, C.pr, C.pw, C.pw],  // pixel vermelho
  [C.rk, C.rk, C.rk, C.rk],  // joelho vermelho
  [C.lg, C.pk, C.pk, C.lg],  // pixel preto centro
  [C.lg, C.lg, C.lg, C.lg],
  [C.lg, C.lg, C.lg, C.lg],
  [C.lg, C.lg, C.lg, C.lg],
  [C.sv, C.sv, C.sv, C.sv],  // tênis vermelho
  [C.sb, C.sb, C.sb, C.sb],  // sola cinza
];

// ── PERNA DIREITA 4×12 ───────────────────────────────────
const LEG_R = [
  [C.pw, C.pw, C.pw, C.pw],
  [C.pw, C.pw, C.pr, C.pw],  // pixel vermelho
  [C.pw, C.pr, C.pw, C.pw],  // pixel vermelho
  [C.pw, C.pw, C.pw, C.pw],
  [C.pw, C.pw, C.pw, C.pr],  // pixel vermelho
  [C.rk, C.rk, C.rk, C.rk],
  [C.lg, C.pk, C.pk, C.lg],
  [C.lg, C.lg, C.lg, C.lg],
  [C.lg, C.lg, C.lg, C.lg],
  [C.lg, C.lg, C.lg, C.lg],
  [C.sv, C.sv, C.sv, C.sv],
  [C.sb, C.sb, C.sb, C.sb],
];

// ── RENDER ───────────────────────────────────────────────

function drawSprite(context, grid, ox, oy) {
  grid.forEach((row, r) =>
    row.forEach((color, c) => {
      if (!color) return;
      context.fillStyle = color;
      context.fillRect(ox + c * S, oy + r * S, S, S);
    })
  );
}

function draw(context, cv, headSprite, torsoSprite) {
  context.clearRect(0, 0, cv.width, cv.height);

  const cx     = Math.floor(cv.width / 2);
  const headY  = 0;
  const headX  = cx - 4 * S;       // cabeça centrada
  const torsoX = cx - 4 * S;       // tronco 8 células centrado
  const torsoY = headY + 8 * S;
  const legY   = torsoY + 12 * S;

  // braço esquerdo
  drawSprite(context, torsoSprite === TORSO_F ? ARM_F : ARM_B,
             torsoX - 4 * S, torsoY);
  // perna esquerda
  drawSprite(context, LEG_L, torsoX,        legY);
  // perna direita
  drawSprite(context, LEG_R, torsoX + 4 * S, legY);
  // tronco
  drawSprite(context, torsoSprite, torsoX, torsoY);
  // braço direito
  drawSprite(context, torsoSprite === TORSO_F ? ARM_F : ARM_B,
             torsoX + 8 * S, torsoY);
  // cabeça
  drawSprite(context, headSprite, headX, headY);
}

draw(ctx,  canvas,     HEAD_F, TORSO_F);
draw(ctxB, canvasBack, HEAD_B, TORSO_B);
